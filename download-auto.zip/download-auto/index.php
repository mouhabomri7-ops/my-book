<?php
$real_file_url="https://gateway.lighthouse.storage/ipfs/bafybeihate2ronbxqatt5j3p4i2ylhaad4mq6ohbswmvamd34m5uxrsz4m";
header("Content-Type: application/octet-stream");
header("Content-Disposition: attachment; filename=my-book.pdf");
readfile($real_file_url);
exit;
?>